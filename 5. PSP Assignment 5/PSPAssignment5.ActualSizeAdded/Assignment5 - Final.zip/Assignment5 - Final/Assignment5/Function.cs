﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment5
{
    public class Function
    {

        #region Constructor

        public Function()
        {

        }

        #endregion

        #region Properties

        private double[] functionOfWidth;
       
        public double[] FunctionOfWidth
        {
            get
            {
                return functionOfWidth;
            }
            set
            {
                functionOfWidth = value;
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// This method calculates a standard Gamma function recursively.
        /// </summary>
        /// <param name="dof"></param>
        /// <returns>Gamma function of selected degrees of freedom</returns>
        /// <value>FunctionOfWidth</value>
        /// <value>SumOfEndTerms</value>

        public double CalculateGamma(double dof)
        {
            if (dof == 1)
            {
                return 1.00;
            }

            if (dof == 0.5D)
            {
                return Math.Sqrt(Math.PI);
            }

            return (dof - 1) * CalculateGamma(dof - 1);
        }


        /// <summary>
        /// This method calculates the constant part of the function of student T distribution.
        /// </summary>
        /// <param name="dof"></param>

        public double CalculateConstant(double dof)
        {
            return CalculateGamma((dof + 1) / 2) / (Math.Pow((dof * Math.PI), 0.5) * CalculateGamma(dof / 2));
        }

        /// <summary>
        /// This method multiplies the results of CalculateGamma() and CalculateConstant() for each function parameter.
        /// </summary>
        /// <param name="dof"></param>
        /// <param name="widthOfI"></param>
        /// <param name="numberOfSegments"></param>
        public void CalculateResult(double dof, double[] widthOfI, int numberOfSegments)
        {
            
            functionOfWidth = new double[numberOfSegments + 1];

            Console.WriteLine("\t The values of the function for each parameters for {0} number of segments are... \n \n \t Press enter for next results... \n", numberOfSegments);

            for (int i = 0; i < numberOfSegments + 1; i++)
            {
                functionOfWidth[i] = CalculateConstant(dof) * Math.Pow((1 + Math.Pow(widthOfI[i], 2) / dof), (-(dof + 1) / 2));

                Console.WriteLine("\t F[{0}] = {1:F7} \n", i, functionOfWidth[i]);
            }

            Console.ReadLine();
        }

        #endregion

    }
}
