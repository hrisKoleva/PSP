﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment5
{
    public class Input
    {

        #region Constructor

        public Input()
        { }

        #endregion
        
        #region Properties

        private int numberOfSegments;
        private double dof;
        private double tInterval;
        private int userInput;

        public double Dof
        {
            get
            {
                return dof;
            }
            set
            {
                dof = value;
            }
        }

        public double TInterval
        {
            get
            {
                return tInterval;
            }
            set
            {
                tInterval = value;
            }
        }

        public int NumberOfSegments
        {
            get
            {
                return numberOfSegments;
            }
            set
            {
                numberOfSegments = value;
            }
        }

        public int UserInput
        {
            get
            {
                return userInput;
            }
            set
            {
                userInput = value;
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// This method validates the user input to select degrees of freedom and interval of function parameters.
        /// Prompts the user in case of invalid input.
        /// </summary>
        /// <param name="userInput"></param>
        /// <value>numberOfSegments</value>
        /// <value>numberOfSegments</value>
        /// <value>tInterval</value>
        
        public void ValidateUserInput(int userInput)
            {
                bool isValidUserInput = int.TryParse(Console.ReadLine(), out userInput);

                while (true)
                {
                    if (isValidUserInput == true)
                    {
                        ProcessUserInput(userInput);
                        return;
                    }
                    else
                    {
                        Console.WriteLine("Please Press <1>, <2> or <3> to select a degrees of freedom of the Gamma function and required interval"); ;
                        ValidateUserInput(userInput);
                        break;
                    }
                }
            }

            /// <summary>
            /// Sets degrees of freedom numberOfSegments, the interval tInterval and numberOfSegments to get integrated in further calculations.
            /// </summary>
            /// <param name="userInput"></param>
            
            public void ProcessUserInput(int userInput)
            {
                 switch (userInput)
                {
                    case 1:
                        tInterval = 1.1f;
                        dof = 9;
                        break;
                    case 2:
                        tInterval = 1.1812f;
                        dof = 10;
                        break;
                    case 3:
                        tInterval = 2.750f;
                        dof = 30;
                        break;
                }

                numberOfSegments = 10;

                Console.WriteLine("Selected tInterval is {0:F7}", tInterval);
                Console.WriteLine("Selected DOF is {0}", dof);
                Console.ReadLine();

            }

        #endregion

    }
}
