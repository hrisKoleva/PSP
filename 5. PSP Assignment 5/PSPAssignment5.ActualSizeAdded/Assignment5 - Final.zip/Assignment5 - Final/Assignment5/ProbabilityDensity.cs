﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment5
{
    public class ProbabilityDensity
    {

        #region Constructor

        public ProbabilityDensity()
        {
        }

        #endregion

        #region Properties

        private double multiplier;
        private double probabilityFirstIteration;
        private double probabilityNextIteration;
        private double errorPrecision;

        public double ProbabilityFirstIteration
        {
            get
            {
                return probabilityFirstIteration;
            }
            set
            {
                probabilityFirstIteration = value;
            }
        }

        public double ProbabilityNextIteration
        {
            get
            {
                return probabilityNextIteration;
            }
            set
            {
                probabilityNextIteration = value;
            }
        }

        public double ErrorPrecision
        {
            get
            {
                return errorPrecision;
            }
            set 
            {
                errorPrecision = value;
            }

        }

        #endregion

        #region Methods

        /// <summary>
        /// This method calculates probability density of student T distribution for N=10 number of segments.
        /// </summary>
        /// <param name="sumOfTerms"></param>
        /// <returns>Probability from first calculation iteration</returns>

        public double CalculateProbability(double sumOfTerms, double tInterval, int numberOfSegments)
        {

            multiplier = tInterval / (numberOfSegments * 3);

            probabilityFirstIteration =  multiplier * sumOfTerms;

            Console.WriteLine("\t ------ {0:F12} ------", probabilityFirstIteration);

            Console.ReadLine();

            return probabilityFirstIteration;

        }

        /// <summary>
        /// This method calculates probability density of student T distribution for N=N*2 number of segments.
        /// </summary>
        /// <param name="sumOfTerms"></param>
        /// <param name="numberOfSegments"></param>
        /// <value>ProbabilityFirstIteration</value>
        /// <value>ProbabilityNextIteration</value>

        public double CalculateNextProbability(int numberOfSegments, double tInterval, double dof)
        { 
            numberOfSegments = numberOfSegments * 2;

            
            Terms nextTerms = new Terms();

            nextTerms.CalculateSumOfTerms(numberOfSegments, tInterval, dof);

            multiplier = tInterval / (numberOfSegments * 3);

            probabilityNextIteration = multiplier * nextTerms.SumOfTerms;

            Console.WriteLine(" \t Probability density function of Student T Distribution for \n \t {0} number of segments is \n \n \t Press enter for next results... \n", numberOfSegments);
            Console.WriteLine("\t ------ {0:F12} ------", probabilityNextIteration);

            return probabilityNextIteration;
        }

        public void GetProbabilityWithHigherPrecision(double probabilityFirstIteration, double probabilityNextIteration, double tInterval, int numberOfSegments, double dof)
        {

            errorPrecision = 0.000000000001D;

            bool isNextMoreAccurate = false; //(probabilityFirstIteration - probabilityNextIteration) < errorPrecision ? true : false;

            while (!isNextMoreAccurate)
            {
                if (!((probabilityFirstIteration - probabilityNextIteration) < errorPrecision))
                {
                    CalculateNextProbability(numberOfSegments, tInterval, dof);

                    Console.WriteLine("\n \t The more accurate calculation is... \n \t ------ {0:F5} ------", probabilityNextIteration);
                    Console.ReadLine();
                    isNextMoreAccurate = true;
                   
                }
                else
                {
                    Console.WriteLine("\n \t The more accurate calculation is... \n \t ------ {0:F5} ------", probabilityFirstIteration);
                    Console.ReadLine();

                    return;
                }
            }
          
        }

        #endregion
    }
}
