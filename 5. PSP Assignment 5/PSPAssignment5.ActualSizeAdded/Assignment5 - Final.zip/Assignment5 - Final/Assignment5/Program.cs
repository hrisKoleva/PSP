﻿// ---- Program Assignment #5
// ---- Name: Hristina Koleva
// ---- Numerically integrates the Student’s 
// ---- t-distribution probability density function ( t-distribution pdf) using
// ---- Simpson’s rule. The total probability is the area of the function (the integral)
// ---- from 0 to t. Expected answers assume only the positive portion of the integral.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5
{
    
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\n \t ************************* ");
            Console.WriteLine("\t ** Welcome to Hristina Koleva F66436 PSP Assigment No. 5 \n\n");
            Console.WriteLine("\t ** Please select degrees of freedom: \n\n For \" Degrees of freedom = 9\" \t - press <1> \n For \"Degrees of freedom = 10\" \t - press <2> \n For \"Degrees of freedom = 30\" \t - press <3> \n");
            Console.WriteLine("\t ** Please press Enter to see the results of the calculation of Student T distribution probability density function....");
            Console.WriteLine("\t ************************* ");

            Input input = new Input();
           
            Terms terms = new Terms();
            ProbabilityDensity result = new ProbabilityDensity();

            input.ValidateUserInput(input.UserInput);

            terms.CalculateSumOfTerms(input.NumberOfSegments, input.TInterval, input.Dof);

            Console.WriteLine(" \t Probability density function of Student T Distribution for \n \t {0} number of segments is \n \n \t Press enter for next results... \n", input.NumberOfSegments);
            result.CalculateProbability(terms.SumOfTerms, input.TInterval, input.NumberOfSegments);

          
            result.CalculateNextProbability(input.NumberOfSegments, input.TInterval,  input.Dof);

            
            result.GetProbabilityWithHigherPrecision(result.ProbabilityFirstIteration, result.ProbabilityNextIteration, input.TInterval, input.NumberOfSegments, input.Dof);

            Console.ReadLine();
        
        }
    }
}
