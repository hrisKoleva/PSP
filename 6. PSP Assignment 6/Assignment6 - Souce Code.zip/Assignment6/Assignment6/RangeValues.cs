﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment6
{
    public class RangeValues
    {

        #region Constructor

        public RangeValues()
        { }

        #endregion

        #region Properties

        private double[] widthOfI;
    
        public double[] WidthOfI
        {
            get
            {
                return widthOfI;
            }
            set
            {
                widthOfI = value;
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// This method calculates each function parameter for given number of segments
        /// within selected interval
        /// </summary>
        /// <param name="numberOfSegments"></param>
        /// <param name="tInterval"></param>
        /// <value>WidthOfI</value>
        public void GetRangeValues(int numberOfSegments, double tInterval)
        {
            int i;

            widthOfI = new double[numberOfSegments + 1];

            for (i = 0; i < numberOfSegments + 1; i++)
            {
                widthOfI[i] = i * tInterval / numberOfSegments;

            }

        }

        #endregion
    }
}
