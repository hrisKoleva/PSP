﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment6

{
    public class Function
    {

        #region Constructor

        public Function()
        {

        }

        #endregion

        #region Properties

        private double[] functionOfWidth;
       
        public double[] FunctionOfWidth
        {
            get
            {
                return functionOfWidth;
            }
            set
            {
                functionOfWidth = value;
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// This method calculates a standard Gamma function recursively.
        /// </summary>
        /// <param name="dof"></param>
        /// <returns>Gamma function of selected degrees of freedom</returns>
        /// <value>FunctionOfWidth</value>
        /// <value>SumOfEndTerms</value>

        public double CalculateGammaFunction(double dof)
        {
            if (dof == 1)
            {
                return 1.00;
            }

            if (dof == 0.5D)
            {
                return Math.Sqrt(Math.PI);
            }

            return (dof - 1) * CalculateGammaFunction(dof - 1);
        }


        /// <summary>
        /// This method calculates the constant part of the function of student T distribution.
        /// </summary>
        /// <param name="dof"></param>

        public double CalculateConstant(double dof)
        {
            return CalculateGammaFunction((dof + 1) / 2) / (Math.Pow((dof * Math.PI), 0.5) * CalculateGammaFunction(dof / 2));
        }

        /// <summary>
        /// This method multiplies the results of CalculateGammaFunction() and CalculateConstant() for each function parameter.
        /// </summary>
        /// <param name="dof"></param>
        /// <param name="widthOfI"></param>
        /// <param name="numberOfSegments"></param>
        public void CalculateResult(double dof, double[] widthOfI, int numberOfSegments)
        {
            
            functionOfWidth = new double[numberOfSegments + 1];

            for (int i = 0; i < numberOfSegments + 1; i++)
            {
                functionOfWidth[i] = CalculateConstant(dof) * Math.Pow((1 + Math.Pow(widthOfI[i], 2) / dof), (-(dof + 1) / 2));

            }

        }

        #endregion

    }
}
