﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment6
{
    public class ProbabilityDensity
    {

        #region Constructor

        public ProbabilityDensity()
        {
        }

        #endregion

        #region Properties

        private double multiplier;
        private double probabilityFirstIteration;
     
        public double ProbabilityFirstIteration
        {
            get
            {
                return probabilityFirstIteration;
            }
            set
            {
                probabilityFirstIteration = value;
            }
        }


        #endregion

        #region Methods

        /// <summary>
        /// This method calculates probability density of student T distribution for N=10 number of segments.
        /// </summary>
        /// <param name="sumOfTerms"></param>
        /// <returns>Probability from first calculation iteration</returns>

        public double CalculateProbability(double tInterval, int numberOfSegments, double dof)
        {
            Terms getTerms = new Terms();

            getTerms.CalculateSumOfTerms(numberOfSegments, tInterval, dof);

            multiplier = tInterval / (numberOfSegments * 3);

            probabilityFirstIteration =  multiplier * getTerms.SumOfTerms;

            Console.WriteLine("\t ------ {0:F7} ------", probabilityFirstIteration);

            Console.ReadLine();

            return probabilityFirstIteration;

        }


        #endregion
    }
}
