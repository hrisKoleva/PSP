﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment6
{
    public class Input
    {

        #region Constructor

        public Input()
        { }

        #endregion
        
        #region Properties

        private int numberOfSegments;
        private double dof;
        private int userInput;
        private double probability;

        public double Probability
        {
            get
            {
                return probability;
            }
            set
            {
                probability = value;
            }
        }


        public double Dof
        {
            get
            {
                return dof;
            }
            set
            {
                dof = value;
            }
        }


        public int NumberOfSegments
        {
            get
            {
                return numberOfSegments;
            }
            set
            {
                numberOfSegments = value;
            }
        }

        public int UserInput
        {
            get
            {
                return userInput;
            }
            set
            {
                userInput = value;
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// This method validates the user input to select degrees of freedom and interval of function parameters.
        /// Prompts the user in case of invalid input.
        /// </summary>
        /// <param name="userInput"></param>
        /// <value>numberOfSegments</value>
        /// <value>numberOfSegments</value>
        /// <value>tInterval</value>
        
        public void ValidateUserInput(int userInput)
            {
                bool isValidUserInput = int.TryParse(Console.ReadLine(), out userInput);

                while (true)
                {
                    if (isValidUserInput == true)
                    {
                        ProcessUserInput(userInput);
                        return;
                    }
                    else
                    {
                        Console.WriteLine("Please Press <1>, <2> or <3> to select a degrees of freedom of the Gamma function and required interval"); ;
                        ValidateUserInput(userInput);
                        break;
                    }
                }
            }

            /// <summary>
            /// Sets degrees of freedom numberOfSegments, the interval tInterval and numberOfSegments to get integrated in further calculations.
            /// </summary>
            /// <param name="userInput"></param>
            
            public void ProcessUserInput(int userInput)
            {
                 switch (userInput)
                {
                    case 1:
                        probability = 0.20;
                        dof = 6;
                        break;
                    case 2:
                        probability = 0.45;
                        dof = 15;
                        break;
                    case 3:
                        probability = 0.495;
                        dof = 4;
                        break;
                }

                numberOfSegments = 10;

                Console.WriteLine("Selected probability is {0:F7}", probability);
                Console.WriteLine("Selected DOF is {0}", dof);
                Console.ReadLine();

            }

        #endregion

    }
}
