﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment6
{
    public class Terms
    {
        #region Constructor

        public Terms()
        {
           
 
        }

        #endregion

        #region Properties

        private double[] sumOfOddMidTerms;
        private double sumOfTerms;
        private double[] sumOfEvenMidTerms;
        private double sumOfEndTerms;

        public double SumOfTerms
        {
            get
            {
                return sumOfTerms;
            }
            set
            {
                sumOfTerms = value;
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// This method calculates the sum of function values in the formula of probability density.
        /// </summary>
        /// <param name="functionOfWidth"></param>
        /// <param name="numberOfSegments"></param>
        /// <param name="tInterval"></param>
        /// <param name="sumOfEndTerms"></param>
        /// <value>SumOfTerms</value>

        public double CalculateSumOfTerms(int numberOfSegments, double tInterval, double dof)
        {
            
            sumOfOddMidTerms = new double[numberOfSegments];
            sumOfEvenMidTerms = new double[numberOfSegments];

            RangeValues getValues = new RangeValues();
            Function getFunctionValues = new Function();

            getValues.GetRangeValues(numberOfSegments, tInterval);
            getFunctionValues.CalculateResult(dof, getValues.WidthOfI, numberOfSegments);

            sumOfEndTerms = getFunctionValues.FunctionOfWidth[0] + getFunctionValues.FunctionOfWidth[numberOfSegments];

            for (int i = 1; i < numberOfSegments; i += 2)
            {
                sumOfOddMidTerms[i] = getFunctionValues.FunctionOfWidth[i] * 4;

                sumOfTerms += sumOfOddMidTerms[i];

            }

            for (int j = 2; j < numberOfSegments; j += 2)
            {
                sumOfEvenMidTerms[j] = getFunctionValues.FunctionOfWidth[j] * 2;

                sumOfTerms += sumOfEvenMidTerms[j];
            }


            sumOfTerms += sumOfEndTerms;

            return sumOfTerms;
        }

        #endregion
    }
}
