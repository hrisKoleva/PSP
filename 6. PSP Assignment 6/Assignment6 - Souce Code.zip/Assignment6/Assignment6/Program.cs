﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment6
{
    /// <summary>
    /// Numerically integrates the Student’s 
    /// t-distribution probability density function ( t-distribution pdf) using
    /// Simpson’s rule. The total probability is the area of the function (the integral)
    /// from 0 to t. Expected answers assume only the positive portion of the integral.
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\n \t ************************* ");
            Console.WriteLine("\t ** Welcome to Hristina Koleva F66436 PSP Assigment No. 6 \n\n");
            Console.WriteLine("\t ** Please select given probability: \n\n For Probability = 0.20 \t - press <1> \n For Probability = 0.45 \t - press <2> \n For Probability = 0.495 \t - press <3> \n");
            Console.WriteLine("\t ** Please press Enter to see the results of the evaluated <t> used to achieve required probability....");
            Console.WriteLine("\t ************************* ");

            Input input = new Input();
            TValue getTInterval = new TValue();

            input.ValidateUserInput(input.UserInput);

            getTInterval.FindValueOfT(input.Probability, input.NumberOfSegments, input.Dof);
            Console.WriteLine("\t The required value of T is ----- {0:F5} ------", getTInterval.TInterval);
            Console.WriteLine();
            Console.WriteLine("Press Enter twice to exit the program");

            Console.ReadLine();
            Console.ReadLine();
           
        
        }
    }
}
