﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment6
{
    public class TValue
    {
        #region Constructor

        public TValue()
        {
        }

        #endregion

        #region Properties

        private double tInterval;
        private double delta;
        private double errorPrecision;

        public double TInterval
        {
            get
            {
                return tInterval;
            }
            set
            {
                tInterval = value;
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Start with a trial value for upper limit of 1 and calculate the value of the integration.
        /// Compare it to the desired value.
        /// if the result of the integration is too low, pick a larger trial upper limit
        /// if the result of the integration is too high, pick a smaller trial upper limit
        /// </summary>
        /// <param name="probability"></param>
        /// <param name="numberOfSegments"></param>

        public void FindValueOfT(double probability, int numberOfSegments, double dof)
        {
            tInterval = 1.0;
            errorPrecision = 0.0000001;
            delta = 0.5;


            Terms getTerms = new Terms();

            getTerms.CalculateSumOfTerms(numberOfSegments, tInterval, dof);

            ProbabilityDensity getProbability = new ProbabilityDensity();
            getProbability.CalculateProbability(tInterval, numberOfSegments, dof);

            
            while (Math.Abs(probability - getProbability.ProbabilityFirstIteration) > Math.Abs(errorPrecision))
            {
                if (Math.Sign(probability - getProbability.ProbabilityFirstIteration) != Math.Sign(errorPrecision))
                {
                    delta = delta / 2;

                    if (probability > getProbability.ProbabilityFirstIteration)
                    {

                        Console.WriteLine("\t\t\t delta = {0:F7}  \t", delta);
                        Console.WriteLine();

                        tInterval = tInterval + delta;

                        Console.WriteLine("\t\t\t tIterval = {0:F5} \t", tInterval);
                        Console.WriteLine();

                        getProbability.CalculateProbability(tInterval, numberOfSegments, dof);
                    }
                    else if (probability < getProbability.ProbabilityFirstIteration)
                    {
                        Console.WriteLine("\t\t\t delta = {0:F7}\t", delta);
                        Console.WriteLine();

                        tInterval = tInterval - delta;

                        Console.WriteLine("\t\t\t tIterval = {0:F5} \t", tInterval);
                        Console.WriteLine();

                        getProbability.CalculateProbability(tInterval, numberOfSegments, dof);
                    }
                   
                }
                else if (Math.Sign(probability - getProbability.ProbabilityFirstIteration) == Math.Sign(errorPrecision))
                {
                    if (probability > getProbability.ProbabilityFirstIteration)
                    {

                        Console.WriteLine("\t\t\t delta = {0:F7} \t", delta);
                        Console.WriteLine();

                        tInterval = tInterval + delta;

                        Console.WriteLine("\t\t\t tIterval = {0:F5} \t", tInterval);
                        Console.WriteLine();

                        getProbability.CalculateProbability(tInterval, numberOfSegments, dof);
                    }
                    else if (probability < getProbability.ProbabilityFirstIteration)
                    {
                        Console.WriteLine("\t\t\t delta = {0:F7} \t", delta);
                        Console.WriteLine();

                        tInterval = tInterval - delta;

                        Console.WriteLine("\t\t\t tIterval =  {0:F5} \t", tInterval);
                        Console.WriteLine();

                        getProbability.CalculateProbability(tInterval, numberOfSegments, dof);
                    }
                   

                }
                
            }

            return;

        }

        #endregion
    }
}
