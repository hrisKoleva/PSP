﻿// ******************************************************************
//  Program Assignment: PSP2Assignment3
//  Name: Hristina Koleva
//  Description: "PSP2Assignment3" calculates the linear regression parameters and correlation coefficients for a set of n pairs,
//  stored in text file in columns.
//  The program validates user input and input file.
//  Depending on the user selection from 1 to 4 it prints the 2 selected columns and calculates the output values.
//  The result of the program is printed in the console.
// ******************************************************************

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PSP2
{
    class PSP2Assignment3
    {
        // ClassBegin      
        public class Assignment : IDisposable
        {

            #region Public Methods

            // This method validates user input from 1 to 4 and
            // transfers it in selection of columns to be used in the calculations
            // MethodBegin
            public void ValidateUserInput()
            {
                filePath = @"C:\PSP2 Program 4 Assignment\TestData\Test1.txt";
                int userInput;
                bool isValidUserInput = int.TryParse(Console.ReadLine(), out userInput);

                while (true)
                {
                    if (isValidUserInput == true)
                    {
                        ProcessUserInput(userInput);

                        IsValidInputFile();
                        return;
                    }
                    else
                    {

                        Console.WriteLine("Please Press <1>, <2> or <3> to select a test to execute");
                        ValidateUserInput();
                        break;
                    }

                }

            }
            // MethodEnd

            // This method is responsible to process valid and invalid numeric user input
            // MethodBegin
            public void ProcessUserInput(int userInput)
            {
                switch (userInput)
                {
                    case 1:
                        x = 0;
                        break;
                    case 2:
                        x = 1;
                        break;
                    case 3:
                        x = 3;
                        break;
                    case 4:
                        x = 4;
                        break;
                    default:
                        HandleInvalidSelection(userInput);
                        break;
                }
            }
            // MethodEnd

            // This method is responsible to handle invalid non-numeric user input
            // MethodBegin
            public static void HandleInvalidSelection(int userInput)
            {
                Console.WriteLine("You entered an invalid user input - <{0}>. Please try again.", userInput);
                Console.WriteLine("Press any key to exit the program and start it again");
                Console.ReadLine();
                Environment.Exit(0);
            }
            // MethodEnd  

            // This method validates that the input file exists,
            // it also validates that the file is not empty and
            // creates the required input folder 
            // where the user can place the input file.
            // MethodBegin
            public void IsValidInputFile()
            {
                while (true)
                {
                    // Validate that the input files are not empty
                    if (File.Exists(filePath))
                    {
                        FileInfo file = new FileInfo(filePath);

                        if (file.Length == 0)
                        {

                            // Promt user to verify the correct file content.
                            Console.WriteLine("\t Please Copy the input files from the installation folder \n\t to C:\\PSP2 Program 3 Assignment\\TestData \n\t and Press Enter to continue");
                            Console.ReadLine();
                        }
                        else
                        {
                            ReadFile();
                            return;
                        }

                    }
                    else
                    {

                        CreateInputFileFolder();
                        IsValidInputFile();
                        break;
                    }

                }

            }
            // MethodEnd

            // This method is responsible to prompt the user and create a folder for the input file if missing.
            // MethodBegin
            public void CreateInputFileFolder()
            {
                Console.WriteLine("\t Cannot find the input folder and test file. We will create the folder for you.\n\t Please Copy the input files from the installation folder \n\t to C:\\PSP2 Program 3 Assignment\\TestData \n\t and Press Enter");
                programFilesDirectory = Path.GetDirectoryName(filePath);
                Directory.CreateDirectory(programFilesDirectory);
                Console.ReadLine();
            }
            // MethodEnd   

            // This method reads the values from the input file.
            // It splits the numbers in each row by a comma character and
            // stores the values of each row in an array then added as the nodes of a linked list.
            // MethodBegin
            public void ReadFile()
            {

                fileContent = new StreamReader(filePath);

                listOfRealNumbers = new LinkedList<double[]>();

                foreach (string line in File.ReadAllLines(filePath))
                {

                    eachLineInProgramFile = fileContent.ReadLine();
                    eachLineInProgramFile = eachLineInProgramFile.Trim();

                    numbersInARow = eachLineInProgramFile.Split(',');

                    try
                    {
                        listOfRealNumbers.AddLast(Array.ConvertAll(numbersInARow, Double.Parse));
                    }
                    catch (FormatException)
                    {
                        Console.WriteLine("Not all data in the input file is not in correct format. \nPlease make sure each value in a row is numeric and separated by a comma.\n {0}", eachLineInProgramFile);
                    }

                }
            }
           

            // MethodBegin
            public void CalculateNaturalLogarithmForEachItem()
            {
                for (int i = 0; i < listOfRealNumbers.Count; i++)
                {
                    naturalLogarithm = Math.Log(listOfRealNumbers.ElementAt<double[]>(i)[x]);
                    Console.WriteLine("{0:F4}",naturalLogarithm);
                }

                Console.ReadLine();
 
            }
            // MethodEnd

            // MethodBegin
            public void CalculateAverageOfNaturalLogarithm()
            {
                for (int i = 0; i < listOfRealNumbers.Count; i++)
                {
                    countOfValues = listOfRealNumbers.Count;
                    sumOfNaturalLogarithmsX += Math.Log(listOfRealNumbers.ElementAt<double[]>(i)[x]);
                    meanValueX = sumOfNaturalLogarithmsX / countOfValues;

                }
                Console.WriteLine("{0:F4}", meanValueX);
                Console.ReadLine();
            }
            // MethodEnd

            // MethodBegin
            public void CalculateVariance()
            {
                for (int i = 0; i < listOfRealNumbers.Count; i++)
                {
                    variance += (Math.Pow((Math.Log(listOfRealNumbers.ElementAt<double[]>(i)[x]) - meanValueX) ,2)/(countOfValues-1));
                }
               
                Console.WriteLine("{0:F4}", variance);
                Console.ReadLine();

            }
            // MethodEnd

            // MethodBegin
            public void CalculateStandardDeviation()
            {
                standarDeviation = Math.Sqrt(variance);

                Console.WriteLine("{0:F4}",standarDeviation);
                Console.ReadLine();

            }
            // MethodEnd


            // MethodBegin
            public void CalculatedRanges()
            {
                sizes = new string[] { "VS", "S", "M", "L", "VL" };

                logarithmicRanges = new double[] 
                {
                    meanValueX - 2*standarDeviation, 
                    meanValueX - standarDeviation, 
                    meanValueX, 
                    meanValueX + standarDeviation, 
                    meanValueX + 2*standarDeviation 
                };

                for (int i = 0; i < logarithmicRanges.Count(); i++ )
                {

                    Console.WriteLine("Natural Logarithm of {0} = {1:F4}", sizes[i], logarithmicRanges[i]);
                   
                }

                Console.ReadLine();
 
            }
            // MethodEnd

            // MethodBegin
            public void CalculateAntiLogarithm()
            {
                actualSizes = new double[logarithmicRanges.Count()];

                for (int i = 0; i < actualSizes.Count(); i++)
                {
                    actualSizes[i] = Math.Pow(Math.E, logarithmicRanges[i]);
                    Console.WriteLine("{0} = {1:F4}", sizes[i], actualSizes[i] );
                }

                Console.ReadLine();
                
            }
            // MethodEnd


            // The purpose of this method is to satisfy code analysis warning: 
            // Types that own disposable fields should be disposable.
            // MethodBegin
            public void Dispose()
            {
                fileContent.Dispose();
            }
            // MethodEnd  


            #endregion

            #region Private Properties

            private string filePath;
            private string eachLineInProgramFile;
            private StreamReader fileContent;
            private string programFilesDirectory;
            private LinkedList<double[]> listOfRealNumbers;

            private int countOfValues;

            public string[] numbersInARow { get; set; }

            public LinkedList<double> firstColumn { get; set; }

            private double naturalLogarithm;
            private double sumOfNaturalLogarithmsX;
            private double variance;
            private double standarDeviation;
            private string[] sizes;
            private double[] logarithmicRanges;
            private double[] actualSizes;
            private double meanValueX;

            public int x { get; set; }
            public int y { get; set; }

            #endregion

        }
        // ClassEnd

        // ClassBegin
        public class Program
        {
            // This is the main program
            // MethodBegin
            public static void Main(string[] args)
            {

                Console.WriteLine("\t Welcome to Hristina Koleva F66436 PSP2 Assigment No. 3 \n\n");
                Console.WriteLine("\t Please select a test \n\n For \"Test 1 - Size Estimating PROBE A\" \t - press <1> \n For \"Test 2 - Time Estimating PROBE A\" \t - press <2> \n For \"Test 3 - Size Estimating PROBE B\" \t - press <3> \n For \"Test 4 - Time Estimating PROBE B\" \t - press <4>");

                Assignment calculateRelativeSizes = new Assignment();
                calculateRelativeSizes.ValidateUserInput();
                calculateRelativeSizes.ReadFile();
                calculateRelativeSizes.CalculateNaturalLogarithmForEachItem();
                calculateRelativeSizes.CalculateAverageOfNaturalLogarithm();
                calculateRelativeSizes.CalculateVariance();
                calculateRelativeSizes.CalculateStandardDeviation();
                calculateRelativeSizes.CalculatedRanges();
                calculateRelativeSizes.CalculateAntiLogarithm();
            }
            // MethodEnd
        }
        // ClassEnd
    }
}
