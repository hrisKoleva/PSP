﻿// ******************************************************************
//  Program Assignment: PSP2Assignment4
//  Name: Hristina Koleva
//  Description: "PSP2Assignment4" calculates relative size table, stored in text files. 
//  The program validates user input and input file.
//  Depending on the user selection 1 or 2 it caclulates
//  -- natural logarithm of each given normalized data
//  -- the average of the natural logarithms
//  -- the variance of the data
//  -- the standard deviation of the data s a root square of the variance
//  -- the logarithmic ranges
//  -- the midpoints of the ranges - Very Small (VS), Small (S), Medium (M), Large (L) and Very Large (VL)
//  The result of the program is printed in the console at each calculation step.
// ******************************************************************

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PSP2
{
    class PSP2Assignment3
    {
        // ClassBegin      
        public class Assignment : IDisposable
        {

            #region Public Methods

            // This method validates user input between 1 and 2 and
            // transfers it in selection of a test file with values to be used in the calculations.
            // MethodBegin
            public void ValidateUserInput()
            {                
                int userInput;
                bool isValidUserInput = int.TryParse(Console.ReadLine(), out userInput);

                while (true)
                {
                    if (isValidUserInput == true)
                    {
                        ProcessUserInput(userInput);

                        IsValidInputFile();
                        return;
                    }
                    else
                    {
                        Console.WriteLine("\t You entered a letter or character which is invalid user input. \n \t Please select a number between 1 and 7 and press Enter.");
                        ValidateUserInput();
                        break;
                    }
                }
            }
            // MethodEnd

            // This method is responsible to process valid and invalid numeric user input.
            // MethodBegin
            public void ProcessUserInput(int userInput)
            {
                switch (userInput)
                {
                    case 1:
                        filePath = @"C:\PSP2 Program 4 Assignment\TestData\Test1LOCPerMethod.txt";
                        break;
                    case 2:
                        filePath = @"C:\PSP2 Program 4 Assignment\TestData\Test2PagesPerChapter.txt";
                        break;
                    case 3:
                        filePath = @"C:\PSP2 Program 4 Assignment\TestData\Test3Assignment4LOCPerMethod.txt";
                        break;
                    case 4:
                        filePath = @"C:\PSP2 Program 4 Assignment\TestData\Test4Assignment3LOCPerMethod.txt";
                        break;
                    case 5:
                        filePath = @"C:\PSP2 Program 4 Assignment\TestData\Test5Assignment2LOCPerMethod.txt";
                        break;
                    case 6:
                        filePath = @"C:\PSP2 Program 4 Assignment\TestData\Test6Assignment1LOCPerMethod.txt";
                        break;
                    case 7:
                        filePath = @"C:\PSP2 Program 4 Assignment\TestData\Test7InvalidContent.txt";
                        break;
                    default:
                        HandleInvalidSelection(userInput);
                        break;
                }
            }
            // MethodEnd

            // This method is responsible to handle invalid non-numeric user input.
            // MethodBegin
            public static void HandleInvalidSelection(int userInput)
            {
                Console.WriteLine("\t You entered an invalid user input - <{0}>. Please try again.", userInput);
                Console.WriteLine("\t Press any key to exit the program and start it again");
                Console.ReadLine();
                Environment.Exit(0);
            }
            // MethodEnd  

            // This method validates that the input file exists,
            // it also validates that the file is not empty. 
            // MethodBegin
            public void IsValidInputFile()
            {
                while (true)
                {
                    if (File.Exists(filePath))
                    {
                        FileInfo file = new FileInfo(filePath);

                        if (file.Length == 0)
                        {

                            // Promt user to verify the correct file content.
                            Console.WriteLine("\t Please Copy the input files from the installation folder \n\t to C:\\PSP2 Program 4 Assignment\\TestData \n\t and Press Enter to continue");
                            Console.ReadLine();
                        }
                        else
                        {
                            ReadFile();
                            return;
                        }
                    }
                    else
                    {
                        CreateInputFileFolder();
                        IsValidInputFile();
                        break;
                    }
                }
            }
            // MethodEnd

            // This method is responsible to prompt the user and create a folder for the input file if missing.
            // MethodBegin
            public void CreateInputFileFolder()
            {
                Console.WriteLine("\t Cannot find the input folder and test file. We will create the folder for you.\n\t Please Copy the input files from the installation folder \n\t to C:\\PSP2 Program 4 Assignment\\TestData \n\t and Press Enter");
                programFilesDirectory = Path.GetDirectoryName(filePath);
                Directory.CreateDirectory(programFilesDirectory);
                Console.ReadLine();
            }
            // MethodEnd   

            // This method reads the values from the input file.
            // It splits the numbers in each row by a comma character and
            // stores the values of each row in a linked list. 
            // MethodBegin
            public void ReadFile()
            {
                fileContent = new StreamReader(filePath);
                listOfRealNumbers = new LinkedList<double>();

                foreach (string line in File.ReadAllLines(filePath))
                {
                    eachLineInProgramFile = fileContent.ReadLine();
                    eachLineInProgramFile = eachLineInProgramFile.Trim();

                    try
                    {
                        listOfRealNumbers.AddLast(double.Parse(eachLineInProgramFile));
                    }
                    catch (FormatException)
                    {
                        Console.WriteLine("\t \"{0}\" is not a numeric value. Please make sure each row in the file contains only numbers.", eachLineInProgramFile);
                        Console.WriteLine("\n \t Please restart the program and try again with corrected data. Press Enter to exit the program.");
                        Console.ReadLine();
                        Environment.Exit(0);
                    }
                }
            }
            // MethodEnd

            // The responsibility of this method is only to prompt the user to press Enter to see the next results.
            // MethodBegin
            public void ShowNextResult()
            {
                Console.WriteLine("\n \n \t Please press Enter to see the result of the next calculation step \n");
            }
            // MethodEnd

            // This method prints the input sizes per item to the console.
            // MethodBegin
            public void PrintInputData()
            {
                for (int i = 0; i < listOfRealNumbers.Count; i++)
                {

                    Console.WriteLine("\t {0:F4}", listOfRealNumbers.ElementAt<double>(i));
                }

                ShowNextResult();
                Console.ReadLine();
            }
            // MethodEnd

            // This method log-normally transforms the size per item data.
            // MethodBegin
            public void CalculateNaturalLogarithmForEachItem()
            {
                for (int i = 0; i < listOfRealNumbers.Count; i++)
                {
                    naturalLogarithm = Math.Log(listOfRealNumbers.ElementAt<double>(i));
                    Console.WriteLine("\t {0:F4}",naturalLogarithm);
                }

                ShowNextResult();
                Console.ReadLine();
            }
            // MethodEnd

            // This methof calculates the average of the transformed data.
            // MethodBegin
            public void CalculateAverageOfNaturalLogarithm()
            {
                for (int i = 0; i < listOfRealNumbers.Count; i++)
                {
                    countOfValues = listOfRealNumbers.Count;
                    sumOfNaturalLogarithmsX += Math.Log(listOfRealNumbers.ElementAt<double>(i));
                    meanValueX = sumOfNaturalLogarithmsX / countOfValues;
                }
                Console.WriteLine("\t {0:F4}", meanValueX);
                ShowNextResult();
                Console.ReadLine();
            }
            // MethodEnd

            // This method calculates the variance of the logarithms.
            // MethodBegin
            public void CalculateVariance()
            {
                for (int i = 0; i < listOfRealNumbers.Count; i++)
                {
                    variance += (Math.Pow((Math.Log(listOfRealNumbers.ElementAt<double>(i)) - meanValueX) ,2)/(countOfValues-1));
                }
               
                Console.WriteLine("\t {0:F4}", variance);
                ShowNextResult();
                Console.ReadLine();
            }
            // MethodEnd

            // This method calculates the standard deviation as a square root of the variances.
            // MethodBegin
            public void CalculateStandardDeviation()
            {
                standarDeviation = Math.Sqrt(variance);

                Console.WriteLine("\t {0:F4}",standarDeviation);
                ShowNextResult();
                Console.ReadLine();
            }
            // MethodEnd

            // This method calculates the logarithmic ranges
            // It defines the ranges as a string array then
            // the logarithmic ranges as an array of doubles and
            // prints the result for each relative size.
            // MethodBegin
            public void CalculatedRanges()
            {
                sizes = new string[] { "VS", "S", "M", "L", "VL" };

                logarithmicRanges = new double[] 
                {
                    meanValueX - 2*standarDeviation, 
                    meanValueX - standarDeviation, 
                    meanValueX, 
                    meanValueX + standarDeviation, 
                    meanValueX + 2*standarDeviation 
                };

                for (int i = 0; i < logarithmicRanges.Count(); i++ )
                {
                    Console.WriteLine("\t Natural Logarithm of {0} = {1:F4}", sizes[i], logarithmicRanges[i]);
                }

                ShowNextResult();
                Console.ReadLine();
            }
            // MethodEnd

            // This is the method to anti-logarithm the results which gives
            // the original forms, i.e. the midpoints of the size ranges.
            // MethodBegin
            public void CalculateAntiLogarithm()
            {
                actualSizes = new double[logarithmicRanges.Count()];

                for (int i = 0; i < actualSizes.Count(); i++)
                {
                    actualSizes[i] = Math.Pow(Math.E, logarithmicRanges[i]);
                    Console.WriteLine("\t {0} = {1:F4}", sizes[i], actualSizes[i] );
                }

                Console.WriteLine("\n \t ******************************\n");
                Console.WriteLine("\n \t Thank you! You can now press Enter to exit the program");
                Console.ReadLine();
            }
            // MethodEnd

            // This method prints the welcome message.
            // MethodBegin
            public void WelcomeMessage()
            {
                Console.WriteLine("\t ******************************\n");
                Console.WriteLine("\t Welcome to Hristina Koleva F66436 PSP2 Assigment No. 4 \n\n");
                Console.WriteLine("\t Please select a test: \n\n \t For \"Test 1 LOC per Method \" \t - press <1> and Enter \n \t For \"Test 2 Pages per Chapter\" \t - press <2> and Enter ");
                Console.WriteLine("\t You may also take look at the LOC/Method relative sizes for Programs 1 to 4 \t - select number from <3> to <6> and press Enter.");
                Console.WriteLine("\t ******************************\n");
            }
            // MethodEnd

            // The purpose of this method is to satisfy code analysis warning: 
            // Types that own disposable fields should be disposable.
            // MethodBegin
            public void Dispose()
            {
                fileContent.Dispose();
            }
            // MethodEnd  

            #endregion

            #region Private Properties

            private string filePath;
            private string eachLineInProgramFile;
            private StreamReader fileContent;
            private string programFilesDirectory;
            private LinkedList<double> listOfRealNumbers;
            private int countOfValues;
            public string[] numbersInARow { get; set; }
            public LinkedList<double> firstColumn { get; set; }
            private double naturalLogarithm;
            private double sumOfNaturalLogarithmsX;
            private double variance;
            private double standarDeviation;
            private string[] sizes;
            private double[] logarithmicRanges;
            private double[] actualSizes;
            private double meanValueX;

            #endregion
        }
        // ClassEnd

        // ClassBegin
        public class Program
        {
            // This is the main program.
            // MethodBegin
            public static void Main(string[] args)
            {
                Assignment calculateRelativeSizes = new Assignment();
                calculateRelativeSizes.WelcomeMessage();
                calculateRelativeSizes.ValidateUserInput();
                calculateRelativeSizes.ReadFile();
                
                Console.WriteLine("\t The input SIZES per item are: \n");
                Console.WriteLine("\t ------------------------------\n");
                calculateRelativeSizes.PrintInputData();

                CalculationsCalls(calculateRelativeSizes);
                
            }
            // MethodEnd

            // This method organize the calls to the methods at each calculation step.
            // MethodBegin
            public static void CalculationsCalls(Assignment calculateRelativeSizes)
            {
                Console.WriteLine("\t The NATURAL LOGARITHMS of each size per item is: \n");
                Console.WriteLine("\t ------------------------------\n");
                calculateRelativeSizes.CalculateNaturalLogarithmForEachItem();

                Console.WriteLine("\t The AVERAGE of the natural logarithms (parts in the category) is: \n");
                Console.WriteLine("\t ------------------------------\n");
                calculateRelativeSizes.CalculateAverageOfNaturalLogarithm();

                Console.WriteLine("\t The VARIANCE of the natural logarithms is: \n");
                Console.WriteLine("\t ------------------------------\n");
                calculateRelativeSizes.CalculateVariance();

                Console.WriteLine("\t The STANDARD DEVIATION of the natural logarithms is: \n");
                Console.WriteLine("\t ------------------------------\n");
                calculateRelativeSizes.CalculateStandardDeviation();

                Console.WriteLine("\t The LOGARITHMIC RANGES are: \n");
                Console.WriteLine("\t ------------------------------\n");
                calculateRelativeSizes.CalculatedRanges();

                Console.WriteLine("\t The MIDPOINTS of the SIZE RANGES (anti-logarithms): are: \n");
                Console.WriteLine("\t ------------------------------\n");
                calculateRelativeSizes.CalculateAntiLogarithm();
            }
            // MethodEnd
        }
        // ClassEnd
    }
}