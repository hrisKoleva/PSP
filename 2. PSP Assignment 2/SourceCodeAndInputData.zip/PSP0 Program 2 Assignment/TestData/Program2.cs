﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;
using System.Reflection;
using System.Diagnostics;

namespace PSP0
{
    class PSP0Assignment1
    {
        // ClassBegin      
        public class Assignment : IDisposable
        {

            #region Public Methods

            // MethodBegin
            public void CreateOutPutFile()
            {

                currentOutput = Console.Out;
                fileStream = new FileStream(resultFilePath, FileMode.Create);
                streamWriter = new StreamWriter(fileStream);
                streamWriter.AutoFlush = true;

                Console.SetOut(streamWriter);

            }
            // MethodEnd  

            // MethodBegin
            public void ValidateUserInput()
            {

                int userInput;
                bool isValidUserInput = int.TryParse(Console.ReadLine(), out userInput);

                while (true)
                {
                    if (isValidUserInput == true)
                    {
                        // Destinguish user input and set the selected file path
                        switch (userInput)
                        {
                            case 1:
                                filePath = @"C:\PSP0 Program 1 Assignment\TestData\PSPTest01.DevelopmentHours.txt"; ;
                                resultFilePath = @"C:\PSP0 Program 1 Assignment\TestData\Result.PSPTest01.DevelopmentHours.txt";
                                break;
                            case 2:
                                filePath = @"C:\PSP0 Program 1 Assignment\TestData\PSPTest02.EstimatedProxySize.txt";
                                resultFilePath = @"C:\PSP0 Program 1 Assignment\TestData\Result.PSPTest02.EstimatedProxySize.txt";
                                break;
                            case 3:
                                filePath = @"C:\PSP0 Program 1 Assignment\TestData\PSPTest03.Example.txt";
                                resultFilePath = @"C:\PSP0 Program 1 Assignment\TestData\Result.PSPTest03.Example.txt";
                                break;
                            default:
                                Console.WriteLine("Press any key to exit the program");
                                Console.ReadLine();
                                break;
                        }

                        CreateOutPutFile();

                        IsValidInputFile();
                        return;
                    }
                    else
                    {

                        Console.WriteLine("Please Press <1>, <2> or <3> to select a test file");
                        ValidateUserInput();
                        break;
                    }

                }

            }
            // MethodEnd  

            // MethodBegin
            public void IsValidInputFile()
            {
                while (true)
                {
                    //Validate that the input files are not empty
                    if (File.Exists(filePath))
                    {
                        FileInfo file = new FileInfo(filePath);

                        if (file.Length == 0)
                        {

                            //Promt user to verify the correct file content
                            Console.WriteLine("\t Please Copy the program files from the installation folder. \n\t Press Enter to continue");
                            Console.ReadLine();
                        }
                        else
                        {
                            Console.WriteLine("You selected {0}", filePath);
                            Console.WriteLine("\n \t ************************* \n \t Result for TOTAL Size \n \t ************************* \n");
                            ReadFile();

                            return;
                        }

                    }
                    else
                    {

                        Console.WriteLine("\t Cannot find the input folder and test file. We will create the folder for you.\n\t Please Copy the test files from the intallation folder \n\t to C:\\PSP0 Program 2 Assignment\\TestData \n\t Rename the Program.cs file to Program1.cs and Press Enter");
                        programFilesDirectory = Path.GetDirectoryName(filePath);
                        Directory.CreateDirectory(programFilesDirectory);
                        Console.ReadLine();
                        IsValidInputFile();
                        break;
                    }

                }

            }
            // MethodEnd   

            // MethodBegin
            public void ReadFile()
            {
                // A regular expression used to validate the format of the numbers in the file. 
                // Used to avoid exceptions from containing characters. 
                // The decimal numbers in the file must be formatted with a decimal point not comma
                // and must contain at least one numeric character*/
                formatInputFile = new Regex(@"[^0-9\.]+");

                fileContent = new StreamReader(filePath);
                listOfRealNumbers = new LinkedList<double>();

                foreach (string line in File.ReadAllLines(filePath))
                {

                    eachLineInProgramFile = fileContent.ReadLine();
                    eachLineInProgramFile = eachLineInProgramFile.Trim();
                    listOfRealNumbers.AddLast(double.Parse(eachLineInProgramFile));

                }

            }
            // MethodEnd

            // Calculate the numerator in the formula of standard deviation separately and then
            // Calculate the standard deviation!
            // MethodBegin
            public void CalculateStandardDeviation()
            {
                for (int k = 0; k < listOfRealNumbers.Count; k++)
                {
                    difference += Math.Pow((listOfRealNumbers.ElementAt<double>(k) - meanValue), 2);
                    standardDeviation = Math.Sqrt(difference / (listOfRealNumbers.Count - 1));
                }

                /*Print the calculated mean value*/
                Console.WriteLine("\t Calculated standard deviation is: {0:F}!\n", standardDeviation);
                return;
            }
            // MethodEnd


            // Print the values in the file and
            // Calculate the mean value!
            // MethodBegin
            public void CalculateMeanValue()
            {
                for (int i = 0; i < listOfRealNumbers.Count; i++)
                {

                    Console.WriteLine("\t \t {0}", listOfRealNumbers.ElementAt<double>(i));
                    meanValue = listOfRealNumbers.Average();
                }

                //Print the calculated mean value
                Console.WriteLine();
                Console.WriteLine("\t Calculated mean value is:  {0:F}!", meanValue);
                Console.WriteLine("\t __________________________ \n");
            }
            // MethodEnd   

            // MethodBegin
            public void OpenResultFile()
            {
                Process openFile = new System.Diagnostics.Process();
                openFile.StartInfo.FileName = resultFilePath;
                openFile.Start();
            }
            // MethodEnd  

            // MethodBegin
            public void DisposeStreams()
            {
                Console.SetOut(currentOutput);
                Dispose();
            }
            // MethodEnd     

            // MethodBegin
            public void Dispose()
            {
                streamWriter.Dispose();
                fileStream.Dispose();
                fileContent.Dispose();
            }
            // MethodEnd  


            #endregion

            #region Private Properties

            private string filePath;
            private string eachLineInProgramFile;
            private StreamReader fileContent;
            private string programFilesDirectory;
            private LinkedList<double> listOfRealNumbers;
            private double meanValue;
            private double difference;
            private double standardDeviation;
            private string resultFilePath;
            private TextWriter currentOutput;
            private FileStream fileStream;
            private StreamWriter streamWriter;
            private Regex formatInputFile;

            #endregion
        }
        // ClassEnd

        // ClassBegin
        public class Program
        {
            public static void Main(string[] args)
            {

                Console.WriteLine("\t Welcome to Hristina Koleva F66436 PSP0 Assigment No. 1 \n\n");
                Console.WriteLine("\t Please select a test file: \n\n For \"EstimatedProxySize\" test\t - press <1> \n For \"Development Hour\" test\t - press <2> \n For \"Ëxample\" test\t - press <3> \n");

                Assignment calculateMeanAndStdDev = new Assignment();
                calculateMeanAndStdDev.ValidateUserInput();
                calculateMeanAndStdDev.CalculateMeanValue();
                calculateMeanAndStdDev.CalculateStandardDeviation();
                calculateMeanAndStdDev.OpenResultFile();
                calculateMeanAndStdDev.Dispose();

            }
        }
        // ClassEnd
    }
}
