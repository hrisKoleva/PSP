﻿        private string eachLineInProgramFile;
        private StreamReader fileContent;
        private bool checkForRegions;
        private FileStream fileStream;
        private StreamWriter streamWriter;
        private string resultFilePath;
        private TextWriter currentOutput;
        private LinkedList<string> linesInFile;
        private int countMethods;