﻿// ******************************************************************
//  Program Assignment: PSP1Assignment2
//  Name: Hristina Koleva
//  Description: "PSP1Assignment2" calculates lines of code (LOC) of a given C# Class file"
//  It first calcuates the total LOC in the program, 
//  excluding blank lines, empty opening and closing curly brackets, 
//  lines with comments and regions.
//  The program then calculates the LOC in each class, 
//  defined as a part and finally the LOC in each method, 
//  defined as an item in the parts.
//  It adds the calculated number of the line in front of each line of code.
//  If the physical line of code does not satisfies the conditions, 
//  the number of the line is not incremented
//  The result of the program is saved and opened in a text file.
// ******************************************************************

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;

namespace PSP1Assignment2
{
    
    // ClassBegin      
    public class CallculateLinesOfCode  : IDisposable
    {

        #region Public Methods

        // This methods sends the console output to a text file.
        // MethodBegin
        public void CreateOutPutFile()
        {

            currentOutput = Console.Out;
            fileStream = new FileStream(resultFilePath, FileMode.Create);
            streamWriter = new StreamWriter(fileStream);
            streamWriter.AutoFlush = true;
               
            Console.SetOut(streamWriter);
                
        } 
        // MethodEnd  
         
        // This method validates the user input to select an input file and sets the path to the result file.
        // Waits for valid user input or exits the application.
        // MethodBegin
        public void ValidateUserInput()
        {

            int userInput;
            bool isValidUserInput = int.TryParse(Console.ReadLine(), out userInput);

            while (true)
            {
                if (isValidUserInput == true)
                {
                    switch (userInput)
                    {
                        case 1:
                            filePath = @"C:\PSP0 Program 2 Assignment\TestData\Program1.cs";
                            resultFilePath = @"C:\PSP0 Program 2 Assignment\TestData\Result.Program1.txt";
                            break;
                        case 2:
                            filePath = @"C:\PSP0 Program 2 Assignment\TestData\Program2.cs";
                            resultFilePath = @"C:\PSP0 Program 2 Assignment\TestData\Result.Program2.txt";
                            break;
                        case 3:
                            filePath = @"C:\PSP0 Program 2 Assignment\TestData\Test-02.cs";
                            resultFilePath = @"C:\PSP0 Program 2 Assignment\TestData\Result.Test-02.txt";
                            break;
                        case 4:
                            filePath = @"C:\PSP0 Program 2 Assignment\TestData\Test-03.cs";
                            resultFilePath = @"C:\PSP0 Program 2 Assignment\TestData\Result.Test-03.txt";
                            break;
                        case 5:
                            filePath = @"C:\PSP0 Program 2 Assignment\TestData\Test-04.cs";
                            resultFilePath = @"C:\PSP0 Program 2 Assignment\TestData\Result.Test-04.txt";
                            break;
                        case 6:
                            filePath = @"C:\PSP0 Program 2 Assignment\TestData\Test-05.cs";
                            resultFilePath = @"C:\PSP0 Program 2 Assignment\TestData\Result.Test-05.txt";
                            break;
                        case 7:
                            filePath = @"C:\PSP0 Program 2 Assignment\TestData\Test-06.cs";
                            resultFilePath = @"C:\PSP0 Program 2 Assignment\TestData\Result.Test-06.txt";
                            break;
                        case 8:
                            filePath = @"C:\PSP0 Program 2 Assignment\TestData\Test-07.cs";
                            resultFilePath = @"C:\PSP0 Program 2 Assignment\TestData\Result.Test-07.txt";
                            break;
                        default:
                            Console.WriteLine("Press any key to exit the program");
                            Console.ReadLine();
                            Environment.Exit(0);
                            break;
                    }

                    CreateOutPutFile();
                    IsValidInputFile();
                   
                    return; 
                }
                else
                {

                    Console.WriteLine("\t Please Press <1>, <2> or <3> to select a test file.\n Please select a value from 3 to 9 to select a test file");
                    ValidateUserInput();
                    break;
                }

            }
                
        }
        // MethodEnd  
   
        // This method verifies if the input folder and file exists and if it is not empty. 
        // Creates the input/output folder.
        // Waits until user places the correct input files to the input folder
        // MethodBegin
        public void IsValidInputFile()
        {
            while (true)
            {
                if (File.Exists(filePath))
                {
                    FileInfo file = new FileInfo(filePath);

                    if (file.Length == 0)
                    {

                        Console.WriteLine("\t Please Copy the program files from the installation folder. \n\t Press Enter to continue");
                        Console.ReadLine();
                    }
                    else
                    {
                        Console.WriteLine("You selected {0}", filePath);
                        Console.WriteLine("\n \t ************************* \n \t Result for TOTAL Size \n \t ************************* \n");
                        ReadFile();
                           
                        return;
                    }

                }
                    //ToDo: This check was intended to validate if the file is missing and to create the folder for it. But it doesn't work well with CreateOutputFile()!!!!
                else 
                {

                    Console.WriteLine("\t Cannot find the input folder and test file. We will create the folder for you.\n\t Please Copy the test files from the intallation folder \n\t to C:\\PSP0 Program 2 Assignment\\TestData \n\t Rename the Program.cs file to Program1.cs and Press Enter");
                    programFilesDirectory = Path.GetDirectoryName(filePath);
                    Directory.CreateDirectory(programFilesDirectory);
                    Console.ReadLine();
                    IsValidInputFile();
                    break;
                }

            }
              
        }
        // MethodEnd   
  
        // This method reads the selected input file.
        // Fills a LinkedList with lines in the file.
        // Calls methods that validates if a line is countable and calculation method.
        // MethodBegin
        public void ReadFile()
        {

            fileContent = new StreamReader(filePath);
            linesInFile = new LinkedList<string>();

            foreach (string line in File.ReadAllLines(filePath))
            {

                eachLineInProgramFile = fileContent.ReadLine();
                eachLineInProgramFile = eachLineInProgramFile.Trim();
                linesInFile.AddLast(eachLineInProgramFile);
                ValidateCountableLinesOfCode();
                CalculateLinesOfCode();
               
            }
               
        }
        // MethodEnd    

        // This method validates if a line of code must be counted.
        // Defines conditions for blank lines; comments; single brackets; regions; usings and private declarations
        // MethodBegin
        public void ValidateCountableLinesOfCode()
        {
            checkForSpaces = eachLineInProgramFile.Equals(String.Empty);
            checkForComments = eachLineInProgramFile.StartsWith(@"/");
            checkForOpeningSingleBracket = eachLineInProgramFile.StartsWith("{");
            checkForClosingSingleBracket = eachLineInProgramFile.Equals("}");
            checkForRegions = eachLineInProgramFile.StartsWith("#");
            checkForUsings = eachLineInProgramFile.StartsWith(@"using");
            checkedForDeclarations = eachLineInProgramFile.StartsWith(@"private");
            


            isCountableLineOfCode = ((checkForClosingSingleBracket == false) && (checkForOpeningSingleBracket == false) && (checkForComments == false) && (checkForSpaces == false) && (checkForRegions == false) && (checkForUsings == false) && (checkedForDeclarations == false));
               
        }
        // MethodEnd     

        // This method increments a counter if countable line of code is encountered
        // MethodBegin
        public void CalculateLinesOfCode()
        {

            if (isCountableLineOfCode)
            {

                calculatedLinesOfCode++;
            }

            Console.WriteLine("{0} : {1}", calculatedLinesOfCode, eachLineInProgramFile);
               
        return;
              
        }
        // MethodEnd     

        // This method is used to do the calculcations one more time only for lines in Classes
        // MethodBegin
        public void ReadClass()
        {
            fileContent = new StreamReader(filePath);
            
            LinkedList<string> linesInClass = new LinkedList<string>();

            countClasses = 0;

            foreach (string line in File.ReadAllLines(filePath))
            {
                
                eachLineInProgramFile = fileContent.ReadLine();
                eachLineInProgramFile = eachLineInProgramFile.Trim();

                if (eachLineInProgramFile.StartsWith(@"// ClassBegin"))
                {
                    Console.WriteLine("\n \t ******************");
                    Console.WriteLine("\t ** This is where the Class starts!");
                    Console.WriteLine("\t ******************\n");
                          
                    linesInClass.AddFirst(eachLineInProgramFile);
                    calculatedLinesOfCode = 0;

                }

                ValidateCountableLinesOfCode();
                CalculateLinesOfCode();
                
                if (eachLineInProgramFile.Equals(@"// ClassEnd"))
                {
                    countClasses++; 
                    Console.WriteLine("\n \t ******************");
                    Console.WriteLine("\t ** This is where Class {0} ends!", countClasses);
                    Console.WriteLine("\t ** Size of this Class is {0} LOC:", calculatedLinesOfCode);
                    Console.WriteLine("\t ******************\n");
                         
                }

            }

            Console.WriteLine("\n \t ******************");
            Console.WriteLine("\t ** The number of Parts - Classes is: {0}", countClasses);
            Console.WriteLine("\t ******************");
                
        }
        // MethodEnd 

        // This method is used to do the calculcations one more time only for lines in Methods
        // MethodBegin
        public void ReadMethod()
        {
            fileContent = new StreamReader(filePath);

            LinkedList<string> linesInMethod = new LinkedList<string>();

            countMethods = 0;

            foreach (string line in File.ReadAllLines(filePath))
            {
                eachLineInProgramFile = fileContent.ReadLine();
                eachLineInProgramFile = eachLineInProgramFile.Trim();

                if (eachLineInProgramFile.StartsWith(@"// MethodBegin"))
                {
                    Console.WriteLine("\n \t ****************** \t");
                    Console.WriteLine("\t ** This is where the Method begins!");
                    Console.WriteLine("\t ****************** \t \n");

                    linesInMethod.AddFirst(eachLineInProgramFile);
                    calculatedLinesOfCode = 0;

                }

                ValidateCountableLinesOfCode();
                CalculateLinesOfCode();

                if (eachLineInProgramFile.Equals(@"// MethodEnd"))
                {
                    countMethods++;
                    Console.WriteLine("\n \t ******************");
                    Console.WriteLine("\t ** This is where Method {0} ends!", countMethods);
                    Console.WriteLine("\t ** Size of this Method is {0} LOC:", calculatedLinesOfCode);
                    Console.WriteLine("\t ****************** \n");
                }
            }

            Console.WriteLine("\n \t ******************");
            Console.WriteLine("\t **The number of Items - Methods is: {0}", countMethods);
            Console.WriteLine("\t ******************");

        }
        // MethodEnd    

        // This method opens the created in CreateOutputFile() method result text file at the end of the execution
        // MethodBegin
        public void OpenResultFile()
        {
            Process openFile = new System.Diagnostics.Process();
            openFile.StartInfo.FileName = resultFilePath;
            openFile.Start();
        }
        // MethodEnd  
   
        // This method prints the number of Total lines of code in the program
        // MethodBegin
        public void PrintResult()
        {
            Console.WriteLine("\n Total Lines of Code is: \t {0} \n", calculatedLinesOfCode);
            return;
        }
        // MethodEnd     


        // To comply with CA1001 and CA2213 code warnings.
        // A class that creates members of IDisposable types:
        // "FileStream", "StreamReader" and "StreamWriter" 
        // must call Dispose on fields that are of types that implement IDisposable
        // MethodBegin
        public void DisposeStreams()
        {
            Console.SetOut(currentOutput);
            Dispose();
        }
        // MethodEnd     

        // MethodBegin
        public void Dispose()
        {
            streamWriter.Dispose();
            fileStream.Dispose();
            fileContent.Dispose();
        }
        // MethodEnd  
   
        #endregion

        #region Private Properties

        private string filePath;
        private string eachLineInProgramFile;
        private StreamReader fileContent;
        private bool checkForSpaces;
        private bool checkForComments;
        private bool checkForOpeningSingleBracket;
        private bool checkForClosingSingleBracket;
        private bool isCountableLineOfCode;
        private int calculatedLinesOfCode;
        private string programFilesDirectory;
        private bool checkForRegions;
        private FileStream fileStream;
        private StreamWriter streamWriter;
        private string resultFilePath;
        private TextWriter currentOutput;
        private LinkedList<string> linesInFile;
        private int countMethods;
        private int countClasses;
        private bool checkForUsings;
        private bool checkedForDeclarations;
            
        #endregion
            
    }
    // ClassEnd

    // ClassBegin
    public class Program
    {
        // MethodBegin
        static void Main(string[] args)
        {
            Console.WriteLine("\n \t ************************* ");
            Console.WriteLine("\t ** Welcome to Hristina Koleva F66436 PSP1 Assigment No. 2 \n\n");
            Console.WriteLine("\t ** Please select a test file: \n\n For \"Program 1\" \t - press <1> \n For \"Program 2\" \t - press <2> \n");
            Console.WriteLine("\t ** Please press Enter generate result file. \n \n \t ** Result file is created in C:\\PSP0 Program 2 Assignment\\TestData\\");
            Console.WriteLine("\t ************************* ");

            CallculateLinesOfCode calculateLinesOfCode = new CallculateLinesOfCode();

            calculateLinesOfCode.ValidateUserInput();

            calculateLinesOfCode.PrintResult();

            Console.WriteLine("\n \t ************************* \n \t Result for Parts - Classes Size \n \t ************************* \n"); 

            calculateLinesOfCode.ReadClass();
              
            Console.WriteLine("\n \t ************************* \n \t Result for Items - Methods Size \n \t ************************* \n");

            calculateLinesOfCode.ReadMethod();

            calculateLinesOfCode.OpenResultFile();

            calculateLinesOfCode.DisposeStreams();
        }
        // MethodEnd

    }
    // ClassEnd
}