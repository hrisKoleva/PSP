﻿// ******************************************************************
//  MainProgram Assignment: PSPAssignment7
//  Name: Hristina Koleva
//  Description: "PSPAssignment7" calculates the
//    --  linear regression parameters and correlation coefficients for a set of n pairs,
//    --  improved prediction interval
//    --  prediction intervals:
//      --  the Range for a 70% interval.
//      --  the UPI as P  Range(70%) .
//      --  the LPI as P  Range(70%) .
//   --  significance
//  stored in text file in columns.
//  The program validates user input and input file.
//  Depending on the user selection from 1 to 4 it prints the 2 selected columns and calculates the output values.
//  The result of the program is printed in the console.
// ******************************************************************

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assignment7;

namespace Assignment7
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("\t Welcome to Hristina Koleva F66436 PSP2.1 Assigment No. 7 \n\n");
            Console.WriteLine("\t Please select a test \n\n For \"Test 1 - Size Estimating PROBE A\" \n \t - press <1> -> Enter -> <1> -> Enter \n\n For \"Test 2 - Time Estimating PROBE A\" \n \t - press <2> -> Enter -> <2> -> Enter \n\n For \"Test 3 - Size Estimating PROBE A over Programs 2 to 6\" \n \t - press <3> -> Enter -> <3> -> Enter\n\n For \"Test 4 - Time Estimating PROBE A over Programs 2 to 6\" \n \t - press <4> -> Enter -> <4> -> Enter ");

            OutputParameters getOutputParameters = new OutputParameters();
            InputData getInputData = new InputData();

            getOutputParameters.CalculateSignificance();

            getOutputParameters.CalculateNewTForRange();

            getOutputParameters.CalculateStandardDeviation();

            getOutputParameters.CalculateLastPartOfTheProduct();

            getOutputParameters.CalculateFinalRange();

            getOutputParameters.CalculateRangeIntervals();

        }
    }
}

