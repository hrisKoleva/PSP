﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment7
{
    public class ProbabilityDensity
    {

        #region Constructor

        public ProbabilityDensity()
        {
        }

        #endregion

        #region Properties

        private double multiplier;
        private double probability;

        public double Probability
        {
            get
            {
                return probability;
            }
            set
            {
                probability = value;
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// This method calculates probability density of student T distribution for N=10 number of segments.
        /// </summary>
        /// <param name="sumOfTerms"></param>
        /// <returns>Probability from first calculation iteration</returns>

        public double CalculateProbability(double tInterval, int numberOfSegments, double dof)
        {
            Terms getTerms = new Terms();

            numberOfSegments = numberOfSegments * 8;

            getTerms.CalculateSumOfTerms(numberOfSegments, tInterval, dof);

            multiplier = tInterval / (numberOfSegments * 3);

            probability = multiplier * getTerms.SumOfTerms;

            return probability;

        }

        #endregion
    }
}

