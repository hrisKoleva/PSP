﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Assignment7
{
    public class CorrelationRegression : InputData
    {

        #region Constructor

        public CorrelationRegression()
        {

        }

        #endregion

        #region Properties

        private int numberOfSegments;
        public int NumberOfSegments
        {
            get
            {
                return numberOfSegments;
            }
            set
            {
                numberOfSegments = value;
            }
        }

        private double dof;
        public double Dof
        {
            get
            {
                return dof;
            }
            set
            {
                dof = value;
            }
        }

        private double regressionB0;
        public double RegressionB0
        {
            get
            {
                return regressionB0;
            }
            set
            {
                regressionB0 = value;

            }
        }

        private double regressionB1;
        public double RegressionB1
        {
            get
            {
                return regressionB1;
            }
            set
            {
                regressionB1 = value;
            }
        }

        private double improvedPrediction;
        public double ImprovedPrediction
        {
            get
            {
                return improvedPrediction;
            }
            set
            {
                improvedPrediction = value;
            }
        }

        private double correlationR;
        public double CorrelationR
        {
            get
            {
                return correlationR;
            }
            set
            {
                correlationR = value;
            }
        }

        private double meanValueX;
        public double MeanValueX
        {
            get
            {
                return meanValueX;
            }
            set
            {
                meanValueX = value;
            }
        }

        private double meanValueY;
        private double sumOfXYProducts;
        private double sumOfSquareX;
        private double productSquareMeanX;
        private double productMeanXY;
        private double sumOfX;
        private double sumOfY;
        private double sumOfSquareY;

        private double correlationR2;
        public double CorrelationR2
        {
            get
            {
                return correlationR2;
            }
            set
            {
                correlationR2 = value;
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// This method is dedicated to calculate the regression parameters.
        /// </summary>
        public void CalculateRegressionParameters()
        {

            ValidateUserInput();
            ReadFile();

            for (int i = 0; i < ListOfRealNumbers.Count; i++)
            {

                numberOfSegments = ListOfRealNumbers.Count;

                dof = numberOfSegments - 2;

                meanValueX += ListOfRealNumbers.ElementAt<double[]>(i)[X] / numberOfSegments;
                meanValueY += ListOfRealNumbers.ElementAt<double[]>(i)[Y] / numberOfSegments;

                sumOfXYProducts += ListOfRealNumbers.ElementAt<double[]>(i)[X] * ListOfRealNumbers.ElementAt<double[]>(i)[Y];
                sumOfSquareX += Math.Pow(ListOfRealNumbers.ElementAt<double[]>(i)[X], 2);
                productSquareMeanX = numberOfSegments * Math.Pow(meanValueX, 2);
                productMeanXY = numberOfSegments * meanValueX * meanValueY;

                regressionB1 = (sumOfXYProducts - productMeanXY) / (sumOfSquareX - productSquareMeanX);

                regressionB0 = meanValueY - (regressionB1 * meanValueX);

                improvedPrediction = regressionB0 + regressionB1 * EstimatedProxySize;

                Console.WriteLine("\t{0}\t{1}", ListOfRealNumbers.ElementAt<double[]>(i)[X], ListOfRealNumbers.ElementAt<double[]>(i)[Y]);

            }
            Console.WriteLine("\t___________________\n");
            Console.WriteLine("\t Regression parameter B0 is {0:F4}\n\t Regression parameter B1 is {1:F4} \n\t ImprovedPrediction P for the given E is {2:F4}", regressionB0, regressionB1, improvedPrediction);

        }

        /// <summary>
        /// This method is dedicated to calculate the correlation coefficients.
        /// </summary>
        /// <returns>correlationR</returns>

        public double CalculateCorrelationParameters()
        {
            for (int k = 0; k < numberOfSegments; k++)
            {
                sumOfX += ListOfRealNumbers.ElementAt<double[]>(k)[X];
                sumOfY += ListOfRealNumbers.ElementAt<double[]>(k)[Y];
                sumOfSquareY += Math.Pow(ListOfRealNumbers.ElementAt<double[]>(k)[Y], 2);

                correlationR = (numberOfSegments * sumOfXYProducts - sumOfX * sumOfY) / Math.Sqrt((numberOfSegments * sumOfSquareX - Math.Pow(sumOfX, 2)) * (numberOfSegments * sumOfSquareY - Math.Pow(sumOfY, 2)));

                correlationR2 = Math.Pow(correlationR, 2);

            }
            Console.WriteLine("\t___________________\n");
            Console.WriteLine("\t Correlation coefficient r is {0:F4}\n\t Correlation coefficient r^2 is {1:F4}", correlationR, correlationR2);

            return correlationR;
        }
    }
        #endregion
}

