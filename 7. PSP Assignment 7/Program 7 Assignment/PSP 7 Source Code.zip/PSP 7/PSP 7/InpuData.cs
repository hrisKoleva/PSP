﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Assignment7
{
    public class InputData
    {
        #region Constructor

        public InputData()
        { }

        #endregion

        #region Properties

        private string filePath;

        private int x;
        public int X
        {
            get
            {
                return x;
            }
            set
            {
                x = value;
            }
        }

        private int y;

        public int Y
        {
            get
            {
                return y;
            }
            set
            {
                y = value;
            }
        }
        private string programFilesDirectory;
        private StreamReader fileContent;
        private string eachLineInProgramFile;
        private string[] numbersInARow;

        private double estimatedProxySize;

        public double EstimatedProxySize
        {
            get
            {
                return estimatedProxySize;
            }
            set
            {
                estimatedProxySize = value;
            }
        }

        private LinkedList<double[]> listOfRealNumbers;

        public LinkedList<double[]> ListOfRealNumbers
        {
            get
            {
                return listOfRealNumbers;
            }
            set
            {
                listOfRealNumbers = value;
            }
        }

        #endregion

        #region Methods
        /// <summary>
        /// The purpose of this method is to enable user input from keyboard within predefined choices.
        /// </summary>
        public void ValidateUserInput()
        {
            //  filePath = @"C:\PSP Program 7\TestData\CorrelationAndRegressionInputData.txt";
            int userInput;
            bool isValidUserInput = int.TryParse(Console.ReadLine(), out userInput);

            while (true)
            {
                if (isValidUserInput == true)
                {
                    ProcessUserInput(userInput);

                    IsValidInputFile();
                    return;
                }
                else
                {

                    Console.WriteLine("Please Press <1>, <2>, <3> or <4>  to select a test to execute");
                    ValidateUserInput();
                    break;
                }

            }
        }
        /// <summary>
        /// The purpose of this method is to distinguish input data depending on user input.
        /// There are two input files, so this method also sets the correct input files depending on the user input
        /// </summary>
        /// <param name="userInput"></param>
        public void ProcessUserInput(int userInput)
        {
            switch (userInput)
            {
                case 1:
                    filePath = @"C:\PSP Program 7\TestData\CorrelationAndRegressionInputData.txt";
                    x = 0;
                    y = 2;
                    estimatedProxySize = 386;
                    break;
                case 2:
                    filePath = @"C:\PSP Program 7\TestData\CorrelationAndRegressionInputData.txt";
                    x = 0;
                    y = 3;
                    estimatedProxySize = 386;
                    break;
                case 3:
                    filePath = @"C:\PSP Program 7\TestData\PersonalData.txt";
                    x = 0;
                    y = 1;
                    estimatedProxySize = 88.89;
                    break;
                case 4:
                    filePath = @"C:\PSP Program 7\TestData\PersonalData.txt";
                    x = 0;
                    y = 2;
                    estimatedProxySize = 88.89;
                    break;
                default:
                    HandleInvalidSelection(userInput);
                    break;
            }
        }

        /// <summary>
        /// This method provides meaningful user prompt in case of invalid user input
        /// </summary>
        /// <param name="userInput"></param>
        public static void HandleInvalidSelection(int userInput)
        {
            Console.WriteLine("You entered an invalid user input - <{0}>. Please try again.", userInput);
            Console.WriteLine("Press any key to exit the program and start it again");
            Console.ReadLine();
            Environment.Exit(0);
        }

        /// <summary>
        /// This method validates that the input file exists,
        /// it also validates that the file is not empty and
        /// creates the required input folder
        /// where the user can place the input file.
        /// </summary>
        public void IsValidInputFile()
        {
            while (true)
            {
                // Validate that the input files are not empty
                if (File.Exists(filePath))
                {
                    FileInfo file = new FileInfo(filePath);

                    if (file.Length == 0)
                    {

                        // Promt user to verify the correct file content.
                        Console.WriteLine("\t Please Copy the input files from the installation folder \n\t to C:\\PSP Program 7\\TestData \n\t and Press Enter to continue");
                        Console.ReadLine();
                    }
                    else
                    {
                        ReadFile();
                        return;
                    }

                }
                else
                {

                    CreateInputFileFolder();
                    IsValidInputFile();
                    break;
                }

            }

        }

        /// <summary>
        /// This is a helper methof used by IsValidInputFile in order to handle missing data file or folder
        /// </summary>
        public void CreateInputFileFolder()
        {
            Console.WriteLine("\t Cannot find the input folder and test file. We will create the folder for you.\n\t Please Copy the input files from the installation folder \n\t to C:\\PSP Program 7\\TestData \n\t and Press Enter");
            programFilesDirectory = Path.GetDirectoryName(filePath);
            Directory.CreateDirectory(programFilesDirectory);
            Console.ReadLine();
        }

        /// <summary>
        /// This method reads the values from the input file.
        /// It splits the numbers in each row by a comma character and
        /// stores the values of each row in an array then added as the nodes of a linked list.
        /// </summary>
        public void ReadFile()
        {

            fileContent = new StreamReader(filePath);

            listOfRealNumbers = new LinkedList<double[]>();

            foreach (string line in File.ReadAllLines(filePath))
            {

                eachLineInProgramFile = fileContent.ReadLine();
                eachLineInProgramFile = eachLineInProgramFile.Trim();

                numbersInARow = eachLineInProgramFile.Split(',');

                try
                {
                    listOfRealNumbers.AddLast(Array.ConvertAll(numbersInARow, Double.Parse));
                }
                catch (FormatException)
                {
                    Console.WriteLine("Not all data in the input file is not in correct format. \nPlease make sure each value in a row is numeric and separated by a comma.\n {0}", eachLineInProgramFile);
                }

            }
        }

        #endregion
    }
}

