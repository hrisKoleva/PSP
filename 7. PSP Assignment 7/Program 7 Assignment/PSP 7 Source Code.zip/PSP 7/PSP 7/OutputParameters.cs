﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Assignment7;

namespace Assignment7
{
    public class OutputParameters : InputData
    {
        #region Constructor

        public OutputParameters()
        {

        }
        #endregion

        #region Properties

        private double significance;
        public double Significance
        {
            get
            {
                return significance;
            }

            set
            {
                significance = value;
            }
        }

        private double tInterval;
        public double TInterval
        {
            get
            {
                return tInterval;
            }
            set
            {
                tInterval = value;
            }
        }

        private double range;
        public double Range
        {
            get
            {
                return range;
            }
            set
            {
                range = value;
            }
        }

        private double sigma;
        private double sum;
        private double thirdPart;

        public double ThirdPart
        {
            get
            {
                return thirdPart;
            }
            set
            {
                thirdPart = value;
            }
        }

        private double sumBelow;
        public double Sigma
        {
            get
            {
                return sigma;
            }
            set
            {
                sigma = value;
            }
        }

        CorrelationRegression getInputParameters = new CorrelationRegression();

        ProbabilityDensity getProbability = new ProbabilityDensity();

        TValue getTInterval = new TValue();

        #endregion

        #region Methods

        /// <summary>
        /// This method calculates  the significance (the tail area) as 1 - 2* p . (The area under the
        /// curve from –t to t is twice the area from 0 to t, or 2* p ; the remaining area
        /// in the upper and lower tails is 1 - 2* p ).
        /// </summary>
        /// <returns>significance</returns>
        public double CalculateSignificance()
        {
            ValidateUserInput();
            ReadFile();

            getInputParameters.CalculateRegressionParameters();
            getInputParameters.CalculateCorrelationParameters();

            tInterval = (Math.Abs(getInputParameters.CorrelationR) * Math.Sqrt(getInputParameters.NumberOfSegments - 2)) / (double)Math.Sqrt(1 - getInputParameters.CorrelationR2);

            getProbability.CalculateProbability(tInterval, getInputParameters.NumberOfSegments, getInputParameters.Dof);

            significance = 1 - 2 * getProbability.Probability;

            Console.WriteLine("\t___________________\n");
            Console.WriteLine("\t Calculated Significance is {0:E}", significance);

            return significance;
        }

        /// <summary>
        /// This method calculates t(0.35, dof) is the value of t for a t-distribution for n - 2 degrees of freedom
        /// and p = 0.35 (using TValus.cs from Program 6)
        /// </summary>
        public void CalculateNewTForRange()
        {
            getProbability.Probability = 0.35;

            getTInterval.FindValueOfT(getProbability.Probability, getInputParameters.NumberOfSegments, getInputParameters.Dof);

            tInterval = getTInterval.TInterval;

        }

        /// <summary>
        /// This method calculates standard deviation, used for Range calcuation later
        /// </summary>
        /// <returns>sigma - standard deviation</returns>
        public double CalculateStandardDeviation()
        {

            for (int i = 0; i < getInputParameters.NumberOfSegments; i++)
            {

                sum += Math.Pow((ListOfRealNumbers.ElementAt<double[]>(i)[Y] - getInputParameters.RegressionB0 - getInputParameters.RegressionB1 * ListOfRealNumbers.ElementAt<double[]>(i)[X]), 2);

            }

            sigma = Math.Sqrt((1 / (double)(getInputParameters.NumberOfSegments - 2)) * sum);

            return sigma;

        }

        /// <summary>
        /// This is a helper method to simplify the formula for calculating Range
        /// </summary>
        /// <returns>last part of the formula for the Range</returns>
        public double CalculateLastPartOfTheProduct()
        {
            sumBelow = 0.0;

            for (int m = 0; m < getInputParameters.NumberOfSegments; m++)
            {
                sumBelow += Math.Pow((ListOfRealNumbers.ElementAt<double[]>(m)[X] - getInputParameters.MeanValueX), 2);
            }

            thirdPart = Math.Sqrt(1 + 1 / (double)getInputParameters.NumberOfSegments + Math.Pow((EstimatedProxySize - getInputParameters.MeanValueX), 2) / sumBelow);

            return thirdPart;
        }

        /// <summary>
        /// This is the method to calculate the prediction interval, use the following steps.
        /// 1. Calculate the Range for a 70% interval.
        /// </summary>
        /// <returns>range</returns>
        public double CalculateFinalRange()
        {

            range = tInterval * sigma * thirdPart;

            Console.WriteLine("\t___________________\n");
            Console.WriteLine("\n \t ----- RANGE is {0} -----", range);

            return range;
        }

        /// <summary>
        /// This method calculatea the UPI as P + Range(70%) and
        /// the LPI as P - Range(70%) .
        /// </summary>
        public void CalculateRangeIntervals()
        {
            double lowerPredictionInterval;
            double upperPredictionInterval;

            lowerPredictionInterval = getInputParameters.ImprovedPrediction - range;
            upperPredictionInterval = getInputParameters.ImprovedPrediction + range;

            Console.WriteLine("\t___________________\n");
            Console.WriteLine("\t ----- LPI (70%) = {0} -----", lowerPredictionInterval);

            Console.WriteLine("\t___________________\n");
            Console.WriteLine("\t ----- UPI (70%) = {0} -----", upperPredictionInterval);

            Console.WriteLine("\n \n Press Enter to exit the program...");

            Console.ReadLine();

        }

        #endregion

    }

}

